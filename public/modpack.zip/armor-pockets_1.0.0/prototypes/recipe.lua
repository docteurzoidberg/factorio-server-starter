data:extend({
{
    type = "recipe",
    name = "armor-pocket-equipment",
    enabled = false,
    energy_required = 10,
    ingredients =
    {
      {"advanced-circuit", 1},
      {"electronic-circuit", 10},
      {"iron-gear-wheel", 2},
      {"steel-plate", 2},
    },
    result = "armor-pocket-equipment"
  }
  })