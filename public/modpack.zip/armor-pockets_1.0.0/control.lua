-- Placed Equipment
script.on_event(defines.events.on_player_placed_equipment, function(event)

	local player = game.players[event.player_index]    
	local inventorySlots = player.character_inventory_slots_bonus

	-- check if we are adding an armor pocket
    if event.equipment.name == "armor-pocket-equipment" then

		-- add the inventory bonus
		player.character_inventory_slots_bonus = inventorySlots + 10
    	
    	-- log the inventory slot count to console
		--log_inventory_slot_count(player)

    end
end
)

-- Removed Equipment
script.on_event(defines.events.on_player_removed_equipment, function(event)
 
 	local player = game.players[event.player_index]
	local inventory_slots_bonus = player.character_inventory_slots_bonus

	-- check if we are removing an armor pocket
  	if event.equipment == "armor-pocket-equipment" then

  		-- subtract the inventory bonus multiplied by the number of equipment items removed
		inventory_slots_bonus = inventory_slots_bonus - (10 * event.count)

		-- set the player's inventory slot bonus count
		player.character_inventory_slots_bonus = inventory_slots_bonus

    	-- log the inventory slot count to console
		--log_inventory_slot_count(player)

    end
end
)

-- Changed Armor
script.on_event(defines.events.on_player_armor_inventory_changed, function(event)
 
  	local player = game.players[event.player_index]
	local armor = player.get_inventory(defines.inventory.player_armor)
	
	-- check if an armor is equiped, before we do anything
	-- else we set the players inventory bonus count to zero
	if not armor.is_empty() then
		
		local total_slots = 0
		local grid =  armor[1].grid

		-- check if the armor has a grid
		if grid ~= nil then

			-- loop through the equipment in the grid
			for i = 1, #grid.equipment do
			
				-- if the equipment item at index is a pocket, we add bonus slots to the total
				if grid.equipment[i].name == "armor-pocket-equipment" then
					total_slots = total_slots + 10
				end
			end

			-- set the player's inventory slot bonus count to total_slots
			player.character_inventory_slots_bonus = total_slots		
		
		else
			-- set the player's inventory slot bonus count to zero
			player.character_inventory_slots_bonus = 0

		end	

	else
		player.character_inventory_slots_bonus = 0
	end

	-- log the inventory slot count to console
	--log_inventory_slot_count(player)
end
)


function log_inventory_slot_count(player)
	player.print("Bonus inventory slots: +" .. player.character_inventory_slots_bonus)	
end
