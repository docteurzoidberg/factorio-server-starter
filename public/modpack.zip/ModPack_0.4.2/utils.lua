require("config")

function createupgrade(level, params)
	local f_result =
	{
		type = "technology",
		name = params.name_prefix .. level,
		icon = params.icon,
		effects = params.effects or {
			{
				type = params.modifiertype,
				ammo_category = params.ammo_category,
				turret_id = params.turret_id,
				modifier = params.modifier
			}
		},
		prerequisites = {params.neededscience},
		unit =
		{
			ingredients = {
				{"science-pack-1", params.pack_r},
				{"science-pack-2", params.pack_g},
				{"science-pack-3", params.pack_b},
				{"alien-science-pack", params.pack_a},
			},
			time = params.time
		},
		upgrade = "true",
		order = params.order
	}

	f_result.unit.count = params.count

	if level > 1 then
		f_result.prerequisites = {params.name_prefix .. (level - 1)}
		if params.stageusage then
			if (f_modifier > upg_stage0modbound) and not upg_stage1reached then
				f_result.prerequisites[#f_result.prerequisites + 1] = upg_stage1prereq
				upg_stage1reached = true
			elseif  (f_modifier > upg_stage1modbound) and not upg_stage2reached then
				f_result.prerequisites[#f_result.prerequisites + 1] = upg_stage2prereq
				upg_stage2reached = true
			end
		end
	end

	return f_result
end
