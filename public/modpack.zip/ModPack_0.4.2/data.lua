require("prototypes.stackchanges")

require("prototypes.titanium.titanium_ore")
require("prototypes.titanium.titanium_plate")
require("prototypes.titanium.titanium_axe")

require("prototypes.solar_panel.solar_panel_mk2")
require("prototypes.solar_panel.solar_panel_mk3")

require("prototypes.accumulator.accumulator_mk2")
require("prototypes.accumulator.accumulator_mk3")

require("prototypes.robot.construction_robot_mk2")
require("prototypes.robot.logistic_robot_mk2")

require("prototypes.equipment.equipment_grid")
require("prototypes.equipment.battery_h")
require("prototypes.equipment.battery_mk2_h")
require("prototypes.equipment.battery_mk3_h")
require("prototypes.equipment.battery_mk3")
require("prototypes.equipment.energy_shield_mk3")
require("prototypes.equipment.exoskeleton_mk2")
require("prototypes.equipment.fusion_reactor_mk2")

require("prototypes.armor.power_armor_mk3")
require("prototypes.vehicule.car_mk2")
require("prototypes.vehicule.car_mk3")