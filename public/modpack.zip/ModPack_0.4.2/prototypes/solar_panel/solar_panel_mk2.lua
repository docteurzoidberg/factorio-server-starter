data:extend({
-- Item
	{
		type = "item",
		name = "solar-panel-mk2",
		icon = "__ModPack__/graphics/solar_panel/solar-panel-mk2-icon.png",
		flags = {"goes-to-quickbar"},
		subgroup = "energy",
		order = "d[solar-panel]-a[solar-panel]-b",
		place_result = "solar-panel-mk2",
		stack_size = 50
	},

--Recipe
	{
		type = "recipe",
		name = "solar-panel-mk2",
		energy_required = 10,
		enabled = "false",
		ingredients =
		{
			{"solar-panel", 4},
			{"steel-plate", 25},
			{"advanced-circuit", 10}
		},
		result = "solar-panel-mk2"
	},

--Technology
	{
		type = "technology",
		name = "solar-energy-2",
		icon = "__base__/graphics/technology/solar-energy.png",
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "solar-panel-mk2"
			}
		},
		prerequisites = {"solar-energy"},
		unit =
		{
			count = 250,
			ingredients =
			{
				{"science-pack-1", 1},
				{"science-pack-2", 1},
				{"science-pack-3", 1}
			},
			time = 30
		},
		order = "a-h-e",
	},

--Entity
	{
		type = "solar-panel",
		name = "solar-panel-mk2",
		icon = "__ModPack__/graphics/solar_panel/solar-panel-mk2-icon.png",
		flags = {"placeable-neutral", "player-creation"},
		minable = {hardness = 0.2, mining_time = 0.5, result = "solar-panel-mk2"},
		max_health = 500,
		corpse = "big-remnants",
		collision_box = {{-1.4, -1.4}, {1.4, 1.4}},
		selection_box = {{-1.5, -1.5}, {1.5, 1.5}},
		energy_source =
		{
			type = "electric",
			usage_priority = "solar"
		},
		picture =
		{
			filename = "__ModPack__/graphics/solar_panel/solar-panel-mk2.png",
			priority = "high",
			width = 104,
			height = 96
		},
		production = "240kW"
	},
})