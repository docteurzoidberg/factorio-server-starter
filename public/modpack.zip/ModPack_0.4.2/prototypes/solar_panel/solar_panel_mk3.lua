data:extend({
-- Item
	{
		type = "item",
		name = "solar-panel-mk3",
		icon = "__ModPack__/graphics/solar_panel/solar-panel-mk3-icon.png",
		flags = {"goes-to-quickbar"},
		subgroup = "energy",
		order = "d[solar-panel]-a[solar-panel]-c",
		place_result = "solar-panel-mk3",
		stack_size = 50
	},

--Recipe
	{
		type = "recipe",
		name = "solar-panel-mk3",
		energy_required = 10,
		enabled = "false",
		ingredients =
		{
			{"solar-panel-mk2", 4},
			{"titanium-plate", 15},
			{"processing-unit", 10}
		},
		result = "solar-panel-mk3"
	},
  
--Technology
	{
		type = "technology",
		name = "solar-energy-3",
		icon = "__base__/graphics/technology/solar-energy.png",
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "solar-panel-mk3"
			}
		},
		prerequisites = {"solar-energy-2"},
		unit =
		{
			count = 250,
			ingredients =
			{
				{"science-pack-1", 1},
				{"science-pack-2", 1},
				{"science-pack-3", 1},
				{"alien-science-pack", 1}
			},
			time = 30
		},
		order = "a-h-e",
	},

--Entity
	{
		type = "solar-panel",
		name = "solar-panel-mk3",
		icon = "__ModPack__/graphics/solar_panel/solar-panel-mk3-icon.png",
		flags = {"placeable-neutral", "player-creation"},
		minable = {hardness = 0.2, mining_time = 0.5, result = "solar-panel-mk3"},
		max_health = 500,
		corpse = "big-remnants",
		collision_box = {{-1.4, -1.4}, {1.4, 1.4}},
		selection_box = {{-1.5, -1.5}, {1.5, 1.5}},
		energy_source =
		{
			type = "electric",
			usage_priority = "solar"
		},
		picture =
		{
			filename = "__ModPack__/graphics/solar_panel/solar-panel-mk3.png",
			priority = "high",
			width = 104,
			height = 96
		},
		production = "960kW"
	},
})