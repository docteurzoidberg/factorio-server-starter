data:extend({
-- Item
	{
		type = "item",
		name = "logistic-robot-mk2",
		icon = "__ModPack__/graphics/robot/logistic-robot-mk2-icon.png",
		flags = {"goes-to-quickbar"},
		subgroup = "logistic-network",
		order = "a[robot]-a[logistic-robot]-b",
		place_result = "logistic-robot-mk2",
		stack_size = 50
	},

--Recipe
	{
		type = "recipe",
		name = "logistic-robot-mk2",
		enabled = false,
		ingredients =
		{
			{"logistic-robot", 1},
			{"plastic-bar", 10},
			{"processing-unit", 1},
			{"speed-module", 1}
		},
		result = "logistic-robot-mk2"
	},

--Technology
	{
		type = "technology",
		name = "logistic-robotics-2",
		icon = "__base__/graphics/technology/logistic-robotics.png",
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "logistic-robot-mk2"
			},
		},
		prerequisites = {"logistic-robotics", "alien-technology"},
		unit =
		{
			count = 250,
			ingredients =
			{
				{"science-pack-1", 1},
				{"science-pack-2", 1},
				{"science-pack-3", 1},
				{"alien-science-pack", 1}
			},
			time = 60
		},
		order = "c-k-c-b",
	},

--Entity
	{
		type = "logistic-robot",
		name = "logistic-robot-mk2",
		icon = "__ModPack__/graphics/robot/logistic-robot-mk2-icon.png",
		flags = {"placeable-player", "player-creation", "placeable-off-grid", "not-on-map"},
		minable = {hardness = 0.1, mining_time = 0.1, result = "logistic-robot-mk2"},
		resistances = { { type = "fire", percent = 85 } },
		max_health = 200,
		collision_box = {{0, 0}, {0, 0}},
		selection_box = {{-0.5, -1.5}, {0.5, -0.5}},
		max_payload_size = 4,
		speed = 0.1,
		transfer_distance = 0.5,
		max_energy = "3MJ",
		energy_per_tick = "0.05kJ",
		speed_multiplier_when_out_of_energy = 0.2,
		energy_per_move = "5kJ",
		min_to_charge = 0.2,
		max_to_charge = 0.95,
		idle =
		{
			filename = "__ModPack__/graphics/robot/logistic-robot-mk2.png",
			priority = "high",
			line_length = 16,
			width = 41,
			height = 42,
			frame_count = 1,
			shift = {0.015625, -0.09375},
			direction_count = 16,
			y = 42
		},
		idle_with_cargo =
		{
			filename = "__ModPack__/graphics/robot/logistic-robot-mk2.png",
			priority = "high",
			line_length = 16,
			width = 41,
			height = 42,
			frame_count = 1,
			shift = {0.015625, -0.09375},
			direction_count = 16
		},
		in_motion =
		{
			filename = "__ModPack__/graphics/robot/logistic-robot-mk2.png",
			priority = "high",
			line_length = 16,
			width = 41,
			height = 42,
			frame_count = 1,
			shift = {0.015625, -0.09375},
			direction_count = 16,
			y = 126
		},
		in_motion_with_cargo =
		{
			filename = "__ModPack__/graphics/robot/logistic-robot-mk2.png",
			priority = "high",
			line_length = 16,
			width = 41,
			height = 42,
			frame_count = 1,
			shift = {0.015625, -0.09375},
			direction_count = 16,
			y = 84
		},
		shadow_idle =
		{
			filename = "__ModPack__/graphics/robot/logistic-robot-mk2-shadow.png",
			priority = "high",
			line_length = 16,
			width = 59,
			height = 23,
			frame_count = 1,
			shift = {0.96875, 0.609375},
			direction_count = 16,
			y = 23
		},
		shadow_idle_with_cargo =
		{
			filename = "__ModPack__/graphics/robot/logistic-robot-mk2-shadow.png",
			priority = "high",
			line_length = 16,
			width = 59,
			height = 23,
			frame_count = 1,
			shift = {0.96875, 0.609375},
			direction_count = 16
		},
		shadow_in_motion =
		{
			filename = "__ModPack__/graphics/robot/logistic-robot-mk2-shadow.png",
			priority = "high",
			line_length = 16,
			width = 59,
			height = 23,
			frame_count = 1,
			shift = {0.96875, 0.609375},
			direction_count = 16,
			y = 23
		},
		shadow_in_motion_with_cargo =
		{
			filename = "__ModPack__/graphics/robot/logistic-robot-mk2-shadow.png",
			priority = "high",
			line_length = 16,
			width = 59,
			height = 23,
			frame_count = 1,
			shift = {0.96875, 0.609375},
			direction_count = 16
		},
		working_sound = flying_robot_sounds(),
		cargo_centered = {0.0, 0.2},
	},
})