data:extend({

-- Item
	{
		type = "armor",
		name = "power-armor-mk3",
		icon = "__ModPack__/graphics/armor/power-armor-mk3-icon.png",
		flags = {"goes-to-main-inventory"},
		resistances =
		{
			{
				type = "physical",
				decrease = 15,
				percent = 50
			},
			{
				type = "acid",
				decrease = 15,
				percent = 50
			},
			{
				type = "explosion",
				decrease = 25,
				percent = 75
			},
			{
				type = "fire",
				decrease = 0,
				percent = 90
			}
		},
		durability = 30000,
		subgroup = "armor",
		order = "f[power-armor-mk3]",
		stack_size = 1,
		equipment_grid = "huge-equipment-grid",
		inventory_size_bonus = 40
	},

--Recipe
	{
		type = "recipe",
		name = "power-armor-mk3",
		enabled = false,
		energy_required = 40,
		ingredients = 
		{
			{"effectivity-module-3", 20}, 
			{"speed-module-3", 20}, 
			{"processing-unit", 100}, 
			{"titanium-plate", 100}, 
			{"alien-artifact", 500}
		},
		result = "power-armor-mk3"
	},

--Technology
	{
		type = "technology",
		name = "power-armor-3",
		icon = "__base__/graphics/technology/power-armor-mk2.png",
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "power-armor-mk3"
			}
		},
		prerequisites = {"power-armor-2"},
		unit =
		{
			count = 500,
			ingredients = 
			{
				{"science-pack-1", 1}, 
				{"science-pack-2", 1}, 
				{"science-pack-3", 1}, 
				{"alien-science-pack", 3}
			},
			time = 30
		},
		order = "g-c-c"
	},

})