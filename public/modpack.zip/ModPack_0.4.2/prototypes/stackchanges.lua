data.raw.item["iron-ore"].stack_size = 200
data.raw.item["copper-ore"].stack_size = 200
data.raw.item["coal"].stack_size = 200
data.raw.item["stone"].stack_size = 200
data.raw.item["wood"].stack_size = 200

data.raw.item["iron-plate"].stack_size = 200
data.raw.item["copper-plate"].stack_size = 200
data.raw.item["steel-plate"].stack_size = 200
data.raw.item["plastic-bar"].stack_size = 200
data.raw.item["stone-brick"].stack_size = 200
data.raw.item["iron-gear-wheel"].stack_size = 200

data.raw.item["transport-belt"].stack_size = 100
data.raw.item["fast-transport-belt"].stack_size = 100
data.raw.item["express-transport-belt"].stack_size = 100