data:extend({
-- Item
	{
		type = "item",
		name = "titanium-ore",
		icon = "__ModPack__/graphics/titanium/titanium-ore.png",
		flags = {"goes-to-main-inventory"},
		subgroup = "raw-material",
		order = "a-a",
		stack_size = 200
	},

--Recipe
	{
		type = "recipe",
		name = "titanium-ore",
		category = "chemistry",
		energy_required = 5,
		enabled = false,
		ingredients = 
		{
			{"iron-ore", 6},
			{type="fluid", name="sulfuric-acid", amount=5},
			{type="fluid", name="water", amount=2}
		},
		result = "titanium-ore",
		result_count = 2
	},

--Technology
	{
		type = "technology",
		name = "titanium-processing",
		icon = "__base__/graphics/technology/steel-processing.png",
		icon_size = 128,
		prerequisites = {"steel-processing", "optics"},
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "titanium-ore"
			},
			{
				type = "unlock-recipe",
				recipe = "titanium-plate"
			},
			{
				type = "unlock-recipe",
				recipe = "titanium-axe"
			}
		},
		unit =
		{
			count = 250,
			ingredients = 
			{
				{"science-pack-1", 1},
				{"science-pack-2", 1},
				{"science-pack-3", 1}
			},
			time = 15
		},
		order = "c-b"
	}
})