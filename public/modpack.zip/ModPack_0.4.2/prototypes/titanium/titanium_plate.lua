data:extend({
-- Item
	{
		type = "item",
		name = "titanium-plate",
		icon = "__ModPack__/graphics/titanium/titanium-plate.png",
		flags = {"goes-to-main-inventory"},
		subgroup = "raw-material",
		order = "c[titanium-plate]",
		stack_size = 200
	},

--Recipe
	{
		type = "recipe",
		name = "titanium-plate",
		category = "smelting",
		enabled = false,
		energy_required = 5,
		ingredients =
		{
			{"titanium-ore", 1}
		},
		result = "titanium-plate"
	},
})