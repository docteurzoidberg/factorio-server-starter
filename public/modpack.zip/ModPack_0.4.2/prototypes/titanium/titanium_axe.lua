data:extend({
-- Item
	{
		type = "mining-tool",
		name = "titanium-axe",
		icon = "__ModPack__/graphics/titanium/titanium-axe.png",
		flags = {"goes-to-main-inventory"},
		action =
		{
			type="direct",
			action_delivery =
			{
				type = "instant",
				target_effects =
				{
					type = "damage",
					damage = { amount = 16 , type = "physical"}
				}
			}
		},
		durability = 10000,
		subgroup = "tool",
		order = "a[mining]-c[titanium-axe]",
		speed = 6,
		stack_size = 10
	},

--Recipe
	{
		type = "recipe",
		name = "titanium-axe",
		enabled = false,
		ingredients =
		{
			{"titanium-plate", 5},
			{"iron-stick", 4}
		},
		result = "titanium-axe",
		requester_paste_multiplier = 4
	},
})