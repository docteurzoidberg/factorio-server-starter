data:extend({

-- Item
  {
    type = "item",
    name = "battery-mk2-equipment-h",
    icon = "__ModPack__/graphics/equipment/battery-mk2-equipment-h-icon.png",
    placed_as_equipment_result = "battery-mk2-equipment-h",
    flags = {"goes-to-main-inventory"},
    subgroup = "equipment",
    order = "c[battery]-b[battery-equipment-mk2]-b",
    stack_size = 50,
    default_request_amount = 10
  },

--Recipe
{
	type = "recipe",
	name = "battery-mk2-equipment-h",
	enabled = false,
	energy_required = 10,
	ingredients =
	{
		{"battery-equipment-h", 10},
		{"processing-unit", 20}
	},
	result = "battery-mk2-equipment-h"
},

--Equipment
{
	type = "battery-equipment",
	name = "battery-mk2-equipment-h",
	sprite =
	{
		filename = "__ModPack__/graphics/equipment/battery-mk2-equipment-h.png",
		width = 64,
		height = 32,
		priority = "medium"
	},
	shape =
	{
		width = 2,
		height = 1,
		type = "full"
	},
	energy_source =
	{
		type = "electric",
		buffer_capacity = "100MJ",
		input_flow_limit = "1GW",
		output_flow_limit = "1GW",
		usage_priority = "terciary"
	},
	categories = {"armor"}
},

--Technology
{
	type = "technology",
	name = "battery-mk2-equipment",
	icon = "__base__/graphics/technology/battery-mk2-equipment.png",
	prerequisites = {"battery-equipment"},
	effects =
	{
		{
			type = "unlock-recipe",
			recipe = "battery-mk2-equipment"
		},
		{
			type = "unlock-recipe",
			recipe = "battery-mk2-equipment-h"
		}
	},
	unit =
	{
		count = 100,
		ingredients = 
		{
			{"science-pack-1", 1}, 
			{"science-pack-2", 1}, 
			{"science-pack-3", 1}
		},
		time = 30
	},
	order = "g-i-b"
},

})