data:extend({

-- Item
  {
    type = "item",
    name = "battery-mk3-equipment",
    icon = "__ModPack__/graphics/equipment/battery-mk3-equipment-icon.png",
    placed_as_equipment_result = "battery-mk3-equipment",
    flags = {"goes-to-main-inventory"},
    subgroup = "equipment",
    order = "c[battery]-c[battery-equipment-mk3]",
    stack_size = 50,
    default_request_amount = 10
  },

--Recipe
{
	type = "recipe",
	name = "battery-mk3-equipment",
	enabled = false,
	energy_required = 10,
	ingredients =
	{
		{"battery-mk2-equipment", 10},
		{"processing-unit", 40}
	},
	result = "battery-mk3-equipment"
},

--Equipment
{
	type = "battery-equipment",
	name = "battery-mk3-equipment",
	sprite =
	{
		filename = "__ModPack__/graphics/equipment/battery-mk3-equipment.png",
		width = 32,
		height = 64,
		priority = "medium"
	},
	shape =
	{
		width = 1,
		height = 2,
		type = "full"
	},
	energy_source =
	{
		type = "electric",
		buffer_capacity = "500MJ",
		input_flow_limit = "5GW",
		output_flow_limit = "5GW",
		usage_priority = "terciary"
	},
	categories = {"armor"}
},

})