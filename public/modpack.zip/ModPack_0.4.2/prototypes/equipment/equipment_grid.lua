data:extend({
	
	{
		type = "equipment-grid",
		name = "huge-equipment-grid",
		width = 14,
		height = 14,
		equipment_categories = {"armor"}
	},

})