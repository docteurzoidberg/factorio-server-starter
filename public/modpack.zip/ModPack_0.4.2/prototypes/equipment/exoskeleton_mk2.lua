data:extend({

-- Item
{
	type = "item",
	name = "exoskeleton-mk2-equipment",
	icon = "__ModPack__/graphics/equipment/exoskeleton-mk2-icon.png",
	placed_as_equipment_result = "exoskeleton-mk2-equipment",
	flags = {"goes-to-main-inventory"},
	subgroup = "equipment",
    order = "e[exoskeleton]-b[exoskeleton-equipment-mk2]",
	stack_size = 10,
	default_request_amount = 10
},

--Recipe
{
	type = "recipe",
	name = "exoskeleton-mk2-equipment",
	enabled = false,
	energy_required = 10,
	ingredients =
	{
		{"exoskeleton-equipment", 2},
		{"processing-unit", 20},
		{"electric-engine-unit", 10}
	},
	result = "exoskeleton-mk2-equipment"
},

--Technology
{
	type = "technology",
	name = "exoskeleton-mk2-equipment",
	icon = "__ModPack__/graphics/equipment/exoskeleton-mk2-tech.png",
	icon_size = 128,
	prerequisites = {"exoskeleton-equipment"},
	effects =
	{
		{
			type = "unlock-recipe",
			recipe = "exoskeleton-mk2-equipment"
		}
	},
	unit =
	{
	count = 500,
	ingredients = 
	{
		{"science-pack-1", 1}, 
		{"science-pack-2", 1}, 
		{"science-pack-3", 1},
		{"alien-science-pack", 1}
	},
	time = 30
	},
	order = "g-h-b"
},

--Equipment
{
	type = "movement-bonus-equipment",
	name = "exoskeleton-mk2-equipment",
	sprite =
	{
		filename = "__ModPack__/graphics/equipment/exoskeleton-mk2.png",
		width = 64,
		height = 128,
		priority = "medium"
	},
	shape =
	{
		width = 2,
		height = 4,
		type = "full"
	},
	energy_source =
	{
		type = "electric",
		usage_priority = "secondary-input"
	},
	energy_consumption = "500kW",
	movement_bonus = 0.6,
	categories = {"armor"}
},

})