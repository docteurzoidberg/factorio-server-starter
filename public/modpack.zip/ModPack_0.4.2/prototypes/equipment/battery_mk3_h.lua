data:extend({

-- Item
  {
    type = "item",
    name = "battery-mk3-equipment-h",
    icon = "__ModPack__/graphics/equipment/battery-mk3-equipment-h-icon.png",
    placed_as_equipment_result = "battery-mk3-equipment-h",
    flags = {"goes-to-main-inventory"},
    subgroup = "equipment",
    order = "c[battery]-c[battery-equipment-mk3]-b",
    stack_size = 50,
    default_request_amount = 10
  },

--Recipe
{
	type = "recipe",
	name = "battery-mk3-equipment-h",
	enabled = false,
	energy_required = 10,
	ingredients =
	{
		{"battery-mk2-equipment-h", 10},
		{"processing-unit", 40}
	},
	result = "battery-mk3-equipment-h"
},

--Equipment
{
	type = "battery-equipment",
	name = "battery-mk3-equipment-h",
	sprite =
	{
		filename = "__ModPack__/graphics/equipment/battery-mk3-equipment-h.png",
		width = 64,
		height = 32,
		priority = "medium"
	},
	shape =
	{
		width = 2,
		height = 1,
		type = "full"
	},
	energy_source =
	{
		type = "electric",
		buffer_capacity = "500MJ",
		input_flow_limit = "5GW",
		output_flow_limit = "5GW",
		usage_priority = "terciary"
	},
	categories = {"armor"}
},

--Technology
{
	type = "technology",
	name = "battery-mk2-equipment-2",
	icon = "__base__/graphics/technology/battery-mk2-equipment.png",
	prerequisites = {"battery-mk2-equipment"},
	effects =
	{
		{
			type = "unlock-recipe",
			recipe = "battery-mk3-equipment"
		},
		{
			type = "unlock-recipe",
			recipe = "battery-mk3-equipment-h"
		}
	},
	unit =
	{
		count = 200,
		ingredients = 
		{
			{"science-pack-1", 1}, 
			{"science-pack-2", 1}, 
			{"science-pack-3", 1},
			{"alien-science-pack", 1}
		},
		time = 30
	},
	order = "g-i-c"
},

})