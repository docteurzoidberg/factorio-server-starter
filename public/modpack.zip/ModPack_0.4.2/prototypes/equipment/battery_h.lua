data:extend({

-- Item
{
	type = "item",
	name = "battery-equipment-h",
	icon = "__ModPack__/graphics/equipment/battery-equipment-h-icon.png",
	placed_as_equipment_result = "battery-equipment-h",
	flags = {"goes-to-main-inventory"},
	subgroup = "equipment",
	order = "c[battery]-a[battery-equipment]-b",
	stack_size = 50,
	default_request_amount = 10
},

--Recipe
{
	type = "recipe",
	name = "battery-equipment-h",
	enabled = false,
	energy_required = 10,
	ingredients =
	{
		{"battery", 5},
		{"steel-plate", 10}
	},
	result = "battery-equipment-h"
},

--Equipment
{
	type = "battery-equipment",
	name = "battery-equipment-h",
	sprite =
	{
		filename = "__ModPack__/graphics/equipment/battery-equipment-h.png",
		width = 64,
		height = 32,
		priority = "medium"
	},
	shape =
	{
		width = 2,
		height = 1,
		type = "full"
	},
	energy_source =
	{
		type = "electric",
		buffer_capacity = "20MJ",
		input_flow_limit = "200MW",
		output_flow_limit = "200MW",
		usage_priority = "terciary"
	},
	categories = {"armor"}
},

--Technology
{
	type = "technology",
	name = "battery-equipment",
	icon = "__base__/graphics/technology/battery-equipment.png",
	prerequisites = {"armor-making-3", "battery"},
	effects =
	{
		{
			type = "unlock-recipe",
			recipe = "battery-equipment"
		},
		{
			type = "unlock-recipe",
			recipe = "battery-equipment-h"
		},
	},
	unit =
	{
		count = 50,
		ingredients = 
		{
			{"science-pack-1", 1}, 
			{"science-pack-2", 1}
		},
		time = 15
	},
	order = "g-i-a"
},

})