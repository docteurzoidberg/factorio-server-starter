data:extend({

-- Item
{
	type = "item",
	name = "fusion-reactor-mk2-equipment",
	icon = "__ModPack__/graphics/equipment/fusion-reactor-mk2-icon.png",
	placed_as_equipment_result = "fusion-reactor-mk2-equipment",
	flags = {"goes-to-main-inventory"},
	subgroup = "equipment",
    order = "a[energy-source]-c[fusion-reactor-mk2]",
	stack_size = 10,
	default_request_amount = 10
},

--Recipe
{
	type = "recipe",
	name = "fusion-reactor-mk2-equipment",
	enabled = false,
	energy_required = 10,
	ingredients =
	{
		{"fusion-reactor-equipment", 2},
		{"processing-unit", 50},
      	{"alien-artifact", 100}
	},
	result = "fusion-reactor-mk2-equipment"
},

--Technology
{
	type = "technology",
	name = "fusion-reactor-equipment-2",
	icon = "__base__/graphics/technology/fusion-reactor-equipment.png",
	prerequisites = {"fusion-reactor-equipment"},
	effects =
	{
		{
			type = "unlock-recipe",
			recipe = "fusion-reactor-mk2-equipment"
		}
	},
	unit =
	{
	count = 750,
	ingredients = 
	{
		{"science-pack-1", 1}, 
		{"science-pack-2", 1}, 
		{"science-pack-3", 1},
		{"alien-science-pack", 1}
	},
	time = 30
	},
	order = "g-l-b"
},

--Equipment
{
	type = "generator-equipment",
	name = "fusion-reactor-mk2-equipment",
	sprite =
	{
		filename = "__ModPack__/graphics/equipment/fusion-reactor-mk2.png",
		width = 128,
		height = 128,
		priority = "medium"
	},
	shape =
	{
		width = 4,
		height = 4,
		type = "full"
	},
	energy_source =
	{
		type = "electric",
		usage_priority = "primary-output"
	},
	power = "1500kW",
	categories = {"armor"}
},

})