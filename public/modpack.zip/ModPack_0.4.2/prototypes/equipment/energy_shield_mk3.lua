data:extend({

-- Item
{
	type = "item",
	name = "energy-shield-mk3-equipment",
	icon = "__ModPack__/graphics/equipment/energy-shield-mk3-icon.png",
	placed_as_equipment_result = "energy-shield-mk3-equipment",
	flags = {"goes-to-main-inventory"},
	subgroup = "equipment",
	order = "b[shield]-c[energy-shield-equipment-mk3]",
	stack_size = 50,
	default_request_amount = 10
},

--Recipe
{
	type = "recipe",
	name = "energy-shield-mk3-equipment",
	enabled = false,
	energy_required = 10,
	ingredients =
	{
		{"energy-shield-mk2-equipment", 10},
		{"processing-unit", 20}
	},
	result = "energy-shield-mk3-equipment"
},

--Technology
{
	type = "technology",
	name = "energy-shield-mk3-equipment",
	icon = "__ModPack__/graphics/equipment/energy-shield-mk3-tech.png",
	prerequisites = {"energy-shield-mk2-equipment"},
	effects =
	{
	{
		type = "unlock-recipe",
		recipe = "energy-shield-mk3-equipment"
	}
	},
	unit =
	{
	count = 500,
	ingredients = 
	{
		{"science-pack-1", 1}, 
		{"science-pack-2", 1}, 
		{"science-pack-3", 1},
		{"alien-science-pack", 1}
	},
	time = 30
	},
	order = "g-e-c"
},

--Equipment
{
	type = "energy-shield-equipment",
	name = "energy-shield-mk3-equipment",
	sprite =
	{
		filename = "__ModPack__/graphics/equipment/energy-shield-mk3.png",
		width = 64,
		height = 64,
		priority = "medium"
	},
	shape =
	{
		width = 2,
		height = 2,
		type = "full"
	},
	max_shield_value = 500,
	energy_source =
	{
		type = "electric",
		buffer_capacity = "500kJ",
		input_flow_limit = "1MW",
		usage_priority = "primary-input"
	},
	energy_per_shield = "40kJ",
	categories = {"armor"}
},

})