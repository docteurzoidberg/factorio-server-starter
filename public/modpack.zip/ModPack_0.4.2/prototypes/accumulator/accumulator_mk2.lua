data:extend({
-- Item
	{
		type = "item",
		name = "accumulator-mk2",
		icon = "__ModPack__/graphics/accumulator/accumulator-mk2-icon.png",
		flags = {"goes-to-quickbar"},
		subgroup = "energy",
		order = "e[accumulator]-a[accumulator]-b",
		place_result = "accumulator-mk2",
		stack_size = 50
	},

--Recipe
	{
		type = "recipe",
		name = "accumulator-mk2",
		energy_required = 10,
		enabled = "false",
		ingredients =
		{
			{"accumulator", 4},
			{"battery", 10},
			{"steel-plate", 10}
		},
		result = "accumulator-mk2"
	},

--Technology
	{
		type = "technology",
		name = "electric-energy-accumulators-2",
		icon = "__base__/graphics/technology/electric-energy-acumulators.png",
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "accumulator-mk2"
			}
		},
		prerequisites = {"electric-energy-accumulators-1"},
		unit =
		{
			count = 120,
			ingredients =
			{
				{"science-pack-1", 1},
				{"science-pack-2", 1},
				{"science-pack-3", 1}
			},
			time = 30
		},
		order = "c-e-b",
	},
	
--Entity
	{
		type = "accumulator",
		name = "accumulator-mk2",
		icon = "__ModPack__/graphics/accumulator/accumulator-mk2.png",
		flags = {"placeable-neutral", "player-creation"},
		minable = {hardness = 0.2, mining_time = 0.5, result = "accumulator-mk2"},
		max_health = 150,
		corpse = "medium-remnants",
		collision_box = {{-0.9, -0.9}, {0.9, 0.9}},
		selection_box = {{-1, -1}, {1, 1}},
		energy_source =
		{
			type = "electric",
			buffer_capacity = "20MJ",
			usage_priority = "terciary",
			input_flow_limit = "1200kW",
			output_flow_limit = "1200kW"
		},
		picture =
		{
			filename = "__ModPack__/graphics/accumulator/accumulator-mk2.png",
			priority = "extra-high",
			width = 124,
			height = 103,
			shift = {0.7, -0.2}
		},
		charge_animation =
		{
			filename = "__ModPack__/graphics/accumulator/accumulator-mk2-charge-animation.png",
			width = 138,
			height = 135,
			line_length = 8,
			frame_count = 24,
			shift = {0.482, -0.638},
			animation_speed = 0.5
		},
		charge_cooldown = 30,
		charge_light = {intensity = 0.3, size = 7},
		discharge_animation =
		{
			filename = "__ModPack__/graphics/accumulator/accumulator-mk2-discharge-animation.png",
			width = 147,
			height = 128,
			line_length = 8,
			frame_count = 24,
			shift = {0.395, -0.525},
			animation_speed = 0.5
		},
		discharge_cooldown = 60,
		discharge_light = {intensity = 0.7, size = 7},
		vehicle_impact_sound =  { filename = "__ModPack__/sound/car-metal-impact.ogg", volume = 0.65 },
		working_sound =
		{
			sound =
			{
				filename = "__ModPack__/sound/accumulator-working.ogg",
				volume = 1
			},
			idle_sound = {
				filename = "__ModPack__/sound/accumulator-idle.ogg",
				volume = 0.4
			},
			max_sounds_per_type = 5
		},
		circuit_wire_connection_point =
		{
			shadow =
			{
				red = {0.984375, 1.10938},
				green = {0.890625, 1.10938}
			},
			wire =
			{
				red = {0.6875, 0.59375},
				green = {0.6875, 0.71875}
			}
		},
		circuit_connector_sprites = get_circuit_connector_sprites({0.46875, 0.5}, {0.46875, 0.8125}, 26),
		circuit_wire_max_distance = 7.5,
		default_output_signal = "signal-A"
	},
})